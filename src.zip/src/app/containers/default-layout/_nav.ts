import { INavData } from '@coreui/angular';
let usertypeses = localStorage.getItem('usertypeses');
// alert(usertypeses);
// if(usertypeses == "EMPLOY") {
// export const navItems: INavData[] = [
 
//   {
//     name: 'Vendor Management',
//     url: '/vendormanagement',
//     iconComponent: { name: 'cil-drop' }
//   }
// // }
// ,
//   {
//     name: 'User Management',
//     url: '/adminmanagement',
//     // linkProps: { fragment: 'someAnchor' },
//     iconComponent: { name: 'cil-pencil' }
//   },
  
// ];

// }
// export const navItems1: INavData[] = [
 
//   {
//     name: 'Vendor test',
//     url: '/vendormanagement',
//     iconComponent: { name: 'cil-drop' }
//   }
// // }
// ,
//   {
//     name: 'User test',
//     url: '/adminmanagement',
//     // linkProps: { fragment: 'someAnchor' },
//     iconComponent: { name: 'cil-pencil' }
//   },
  
// ];
// }
