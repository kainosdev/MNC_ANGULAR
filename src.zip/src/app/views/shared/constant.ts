export const config_url = "http://localhost/MNC_PHP_API";
